var apigee = require('apigee-access');
var url = require("url");
var apppath = /^\/privatekeys\/\w*$/;


if (apigee.getMode() === 'apigee') {  // test to see if running on Edge
  var envVault = apigee.getVault('privatekeys', 'environment');
}

//Lets require/import the HTTP module
var http = require('http');

//Lets define a port we want to listen to
const PORT=3000;

//We need a function which handles requests and send response
function handleRequest(request, response) {
  if (request.method == 'GET') {
    var pathname = url.parse(request.url).pathname;
    if (pathname != request.url) {
      returnNotFound(response);
    }
    if (pathname.match(apppath) == null) {
      returnNotFound(response);
    }
    var keyName = pathname.split("/");
    envVault.get(keyName[2], function(err, secretValue) {
      // use the secret value here
      response.writeHead(200, {"Content-Type": "text/plain"});
      response.end(secretValue);
    });
  }
  else {
    returnNotFound(response);
  }
}

function returnNotFound(response) {
  var error = {
    status: 404,
    description: "404 Not found"
  }
  response.writeHead(404, {"Content-Type": "application/json"});
  response.write(JSON.stringify(error));
  response.end();
}

//Create a server
var server = http.createServer(handleRequest);

//Lets start our server
server.listen(PORT, function(){
    //Callback triggered when server is successfully listening. Hurray!
    console.log("Server listening on: http://localhost:%s", PORT);
});
