apigeetool deploynodeapp -L http://ec2-174-129-47-34.compute-1.amazonaws.com:8080 -o saml -e prod -v default
